<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

class File extends Authenticatable
{
    protected $fillable = [];
}

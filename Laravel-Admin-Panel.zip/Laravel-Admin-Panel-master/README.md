### Laravel Admin Panel
A simple Laravel Admin Panel application with Laravel.

#### Installation
It's a Laravel 7.22.4 application with a very little functionality. You can install it as any other laravel 7 application. Here are the commands you need to run one by one-
```text
git clone git@github.com:Sajjad-HussainZada/Laravel-Admin-Panel.git admin-panel
cd admin-panel
composer install
php artisan key:generate
php artisan storage:link
```
Then you need to put your database credentials in the .env file. I used MySQL in this project, but any Eloquent supported relational database can be used. After that run these-
```text
php artisan migrate
php artisan serve
```
Then you can visit the url shortener in this url- http://127.0.0.1:8000

#### Uses
This application can be used both in logged in or logged out state. But for using the full potential, you should logged in.

This project has following features-
- Full fledged registration and login system
- Proper validation for each form
- Dynamic Category, Sub-Category, Product
- Live Search
- Filter Product
 
#### Tasks Done:
   1.	Create an Admin Panel with proper user authentication.
   2.	Product Category & Subcategory (CRUD operations)
   3.	Product (CRUD operations)
   4.	Search product using category, subcategory, name
   5.	Filter products by price and date range.
   6.	Use MySQL Database with proper indexing.
   7.	Use Laravel & React.
   8.	Must use race condition.
   9.	Use all of GET, POST, PUT, PATCH and DELETE.

#### Table Requirements:
- Category data contains category_id, category_name and category_slug.

- Product data contains product_id, Product name, category, sub category, description, price, featured/thumbnail image, products multiple images.


#### Developer
Sajjad HussainZada

<a href="{{url('/category')}}" class="btn btn-xs btn-primary">
    <i class="ace-icon fa fa-list bigger-130"></i> View Category
</a>

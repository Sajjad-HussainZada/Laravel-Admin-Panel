<a href="{{url('/product')}}" class="btn btn-xs btn-primary">
    <i class="ace-icon fa fa-list bigger-130"></i> View Product
</a>

<a href="{{url('/subcategory')}}" class="btn btn-xs btn-primary">
    <i class="ace-icon fa fa-list bigger-130"></i> View Sub-Category
</a>

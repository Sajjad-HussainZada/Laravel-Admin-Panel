@extends('layouts.backend')

@section('title', "Dashboard")

@section('heading', "Dashboard")

@section('content_header', 'Overview & Stats')

@section('content')
    <div class="main-content-inner">
        <div class="page-content">
            
            <div class="row">
                <div class="col-sm-12">
                    
                </div>
            </div>
            
            
        </div>
    </div>

@endsection
